﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;
using System.Collections.ObjectModel;

namespace TestProject
{
    class WebdriverWindowTestAtClass : TestBase
    {
        [Test]
        public void ResponsiveWindow()
        {
            Driver.Navigate().GoToUrl("http://barcampomaha.org/");
            //Maximize browser window
            Assert.IsTrue(Driver.FindElement(By.LinkText("Register")).Displayed);
            Assert.IsFalse(Driver.FindElement(By.ClassName("menuButton")).Displayed);
            //Set browser window size to 600x600
            Assert.IsTrue(Driver.FindElement(By.ClassName("menuButton")).Displayed);
            Assert.IsEmpty(Driver.FindElements(By.LinkText("Register")));
        }

        [Test]
        public void MultipleWindow()
        {
            Driver.Navigate().GoToUrl("http://barcampomaha.org/");
            // String firstWindow <= save current window's handle in this string
            new Actions(Driver).KeyDown(Keys.Shift).Click(Driver.FindElement(By.LinkText("Register"))).KeyUp(Keys.Shift).Perform();
            new Actions(Driver).KeyDown(Keys.Shift).Click(Driver.FindElement(By.LinkText("Sponsor"))).KeyUp(Keys.Shift).Perform();
            // ReadOnlyCollection<string> windows <= save all window handles here
            // Switch to last opened window
            Assert.IsTrue(Driver.FindElement(By.ClassName("sponsorRight")).Displayed);
            // Close active window
            // Switch to the other opened window
            Assert.AreEqual("Barcamp Omaha 2014- Eventbrite", Driver.Title);
            // Close active window
            // Switch to our main window
            // Create an assert where you verify that current window handle is the same as firstWindow
        }


    }
}
