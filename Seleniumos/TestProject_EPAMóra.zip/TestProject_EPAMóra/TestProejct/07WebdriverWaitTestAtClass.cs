﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;

namespace TestProject
{
    class WebdriverWaitTestAtClass : TestBase
    {
        [Test]
        public void GoogleWaitTitle()
        {
            Driver.Navigate().GoToUrl("http://www.google.com");
            IWebElement query = Driver.FindElement(By.Name("q"));
            query.SendKeys("Selenium");
            query.Submit();
            //create a WebDriverWait which waits until the page title starts with "Selenium"
            Assert.AreEqual("Selenium - Google keresés", Driver.Title);
        }

        [Test]
        public void GoogleWaitLink()
        {
            Driver.Navigate().GoToUrl("http://www.google.com");
            IWebElement query = Driver.FindElement(By.Name("q"));
            query.SendKeys("Selenium");
            query.Submit();
            //create a WebDriverWait which waits until Picutres link is clickable
            Driver.FindElement(By.LinkText("Képek")).Click();
        }
    }
}