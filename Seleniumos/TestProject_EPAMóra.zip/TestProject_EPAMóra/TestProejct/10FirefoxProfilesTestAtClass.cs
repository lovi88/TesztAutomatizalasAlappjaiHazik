﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;
using System.Collections.ObjectModel;
using System.IO;

namespace TestProject
{
    class FirefoxProfilesTestAtClass : TestBase
    {
        [Test]
        public void FirefoxProfilesSetUserAgent()
        {
            var profile = new FirefoxProfile();
            // Set iPad user agent => "Mozilla/5.0(iPad; U; CPU iPhone OS 3_2 like Mac OS X; en-us) AppleWebKit/531.21.10 (KHTML, like Gecko) Version/4.0.4 Mobile/7B314 Safari/531.21.10"
            IWebDriver driver = new FirefoxDriver(profile);
            driver.Navigate().GoToUrl("http://www.google.com");
        }

        [Test]
        public void FirefoxProfilesSetLanguage()
        {
            FirefoxProfile profile = new FirefoxProfile();
            // Set German language as preferred => "de"
            IWebDriver driver = new FirefoxDriver(profile);
            driver.Navigate().GoToUrl("http://elvira.mav-start.hu/");
        }

        [Test]
        public void FirefoxProfilesAddExtension()
        {
            var profile = new FirefoxProfile();
            
            try 
            {
                string output_dir = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                output_dir = Path.Combine(output_dir, "Firebugnetexports");
                // use Addextension command and set firebug-1.9.2.xpi file with full path as extension
            }
            catch (IOException e)
            {
                Console.WriteLine(e.Message);
            }
            
            IWebDriver driver = new FirefoxDriver(profile);
            driver.Navigate().GoToUrl("http://bookline.hu/");
        }
    }
}
