﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using NUnit.Framework;
using OpenQA.Selenium;

namespace TestProject
{
    class CookieTestAtClass : TestBase
    {
        String visitorCookie = "visitorid";

        [Test]
        public void testVisitorCookie()
        {
            //Delete all cookies
            Driver.Navigate().GoToUrl("http://bookline.hu/");

            // Get visitorid cookie from bookline page
            Cookie cookieUnderTest = null;
            Assert.IsNotNull(cookieUnderTest);
            printCookieInfo(cookieUnderTest);

            searchForBook("Szent Johanna Gimi");
            // Get visitorid cookie again from bookline page
            Cookie updatedCookie = null;
            Assert.IsNotNull(updatedCookie);

            // verify that the VALUE of the 'visitorid' cookie is still the same
            Assert.AreEqual(1, 2);

            // verify that the EXPIRATION DATE of the 'visitorid' cookie is still the same
            Assert.AreEqual(1, 2);
        }

        [Test]
        public void testCookieDeletion()
        {
            Driver.Navigate().GoToUrl("http://bookline.hu/");

            // Get visitorid cookie from bookline page
            Cookie cookieUnderTest = null;
            Assert.IsNotNull(cookieUnderTest);
            printCookieInfo(cookieUnderTest);

            // Save cookieundertest value
            String originalValue = "";
            Assert.IsTrue(originalValue.Length > 0);

            // Delete visitorid cookie
            // Verifiy that visitorid cookie is missing by getting a null
            Assert.IsNull("not null");

            searchForBook("Szent Johanna Gimi");
            // Get visitorid cookie from bookline page again
            Cookie recreatedCookie = null;
            printCookieInfo(recreatedCookie);

            // verify that the original and recreated cookie value is different
            Assert.AreNotEqual(1, 1);
        }

        private void printCookieInfo(Cookie testedCookie)
        {
            Console.Write("\n*******************************************************************\n");
            Console.Write("NAME: " + testedCookie.Name +
                    "\nVALUE: " + testedCookie.Value +
                    "\nEXPIRY: " + testedCookie.Expiry +
                    "\nDOMAIN " + testedCookie.Domain +
                    "\nPATH " + testedCookie.Path +
                    "\nIS SECURE: " + testedCookie.Secure);
            Console.Write("\n*******************************************************************\n");
        }

        private void searchForBook(String bookName)
        {
            Driver.FindElement(By.Id("search_form_field")).SendKeys(bookName);
            Driver.FindElement(By.CssSelector(".button.keresbt")).Submit();
        }
    }
}
