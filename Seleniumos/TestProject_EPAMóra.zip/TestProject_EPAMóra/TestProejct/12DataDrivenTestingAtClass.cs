﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;
using System.Collections;
using System.Xml.Linq;
using OpenQA.Selenium.Firefox;

namespace TestProject
{
    class DataDrivenTestingAtClass : TestBase
    {
        // Expand test attributes
        [Test]
        public void LocalizationXMLTest(String lang, String phone)
        {
            FirefoxProfile profile = new FirefoxProfile();
            profile.SetPreference("intl.accept_languages", lang);
            Driver = new FirefoxDriver(profile);
            Driver.Navigate().GoToUrl("http://elvira.mav-start.hu/");
            String phoneNumberText = Driver.FindElement(By.ClassName("mavdirekt")).Text;
            Console.WriteLine(phoneNumberText);
            Assert.True(phoneNumberText.Contains(phone));
        }

        [Test, TestCaseSource("testData")]
        public void XMLTest(String country, String desc)
        {
            Driver.Navigate().GoToUrl("http://en.wikipedia.org/wiki/Main_Page");
            Driver.FindElement(By.Id("searchInput")).Clear();
            Driver.FindElement(By.Id("searchInput")).SendKeys(country);
            Driver.FindElement(By.Id("searchButton")).Click();
            String officialName = Driver.FindElement(By.XPath("//tr[@class='adr']/th/span")).Text;
            Console.WriteLine(officialName);
            Assert.True(desc.Equals(officialName.Trim()));
        }

        static IEnumerable localizationData()
        {
            // Open and read the contents of localization.xml like data.xml below
            return new object[] { "", "" };
        }

        static IEnumerable testData()
        {
            var doc = XElement.Load(@"C:\\Users\\hallgato\\Desktop\\TestProject_EPAMóra\\data.xml");
            return
                from vars in doc.Descendants("testData")
                let country = vars.Attribute("country").Value
                let desc = vars.Attribute("desc").Value
                select new object[] { country, desc };
        }
    }
}
