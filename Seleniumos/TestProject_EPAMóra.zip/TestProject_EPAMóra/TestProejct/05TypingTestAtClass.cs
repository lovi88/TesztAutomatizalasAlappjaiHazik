﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;

namespace TestProject
{
    class TypingTestAtClass : TestBase
    {
        [Test]
        public void GoogleTypeExample()
        {
            Driver.Navigate().GoToUrl("http://www.google.com");
            // Type selenium word to google search field
            // Verify that selenium string is there with assert
            // Clear google search field
            // Verify that search field is empty
        }
    }
}
