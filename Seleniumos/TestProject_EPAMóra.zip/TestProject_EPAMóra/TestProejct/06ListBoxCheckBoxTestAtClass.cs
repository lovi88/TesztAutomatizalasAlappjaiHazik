﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace TestProject
{
    class ListBoxCheckBoxTestAtClass : TestBase
    {
        [Test]
        public void ListBoxCheckBoxExample()
        {
            Driver.Navigate().GoToUrl("http://elvira.mav-start.hu/");
            Driver.FindElement(By.Id("i")).SendKeys("Budapest");
            Driver.FindElement(By.Id("e")).SendKeys("Tihany");
            Driver.FindElement(By.Name("uff")).Submit();
            // Choose youth under 26 reduction from listbox
            // Set direct connections only
            Driver.FindElement(By.Name("uff")).Submit();
            //Asser youth under 26 is selected
        }
    }
}
