﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Firefox;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace TestProject
{
    class LanguageTest:TestBase
    {
        // Expand test attributes
        [Test, TestCaseSource("localizationData")]
        public void LocalizationXMLTest(String lang, String tel)
        {
            FirefoxProfile profile = new FirefoxProfile();
            profile.SetPreference("intl.accept_languages", lang);
            Driver = new FirefoxDriver(profile);
            Driver.Navigate().GoToUrl("http://elvira.mav-start.hu/");
            String phoneNumberText = Driver.FindElement(By.ClassName("mavdirekt")).Text;
            Console.WriteLine(phoneNumberText);
            Assert.True(phoneNumberText.Contains(tel));
        }

        static IEnumerable localizationData()
        {
            var doc = XElement.Load(@"C:\\Users\\hallgato\\Desktop\\TestProject_EPAMóra\\data2.xml");
            return
                from vars in doc.Descendants("testData")
                let lang = vars.Attribute("lang").Value
                let tel = vars.Attribute("tel").Value
                select new object[] { lang, tel };
        }

 
    }
}
