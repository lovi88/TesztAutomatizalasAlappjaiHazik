﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;

namespace TestProject
{
    class NavigationTestAtClass : TestBase
    {
        private String assertTitleChange(String oldTitle)
        {
            String newTitle = Driver.Title;
            Assert.AreNotEqual(oldTitle, newTitle);
            return newTitle;
        }

        [Test]
        public void NavigationExample()
        {
            String title = "";
            //Navigate to http://www.google.com
            title = assertTitleChange(title);
            //Navigate to http://www.bing.com
            title = assertTitleChange(title);
            //Navigate back
            title = assertTitleChange(title);
            //Navigate forward
            title = assertTitleChange(title);
            //Refresh browser window
            Assert.AreEqual(title, Driver.Title);
            //Create an assert and check current URL
        }
    }
}
