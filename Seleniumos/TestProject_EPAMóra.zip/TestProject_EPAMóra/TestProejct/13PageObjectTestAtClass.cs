﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestProject
{
    class PageObjectTestAtClass : TestBase
    {
        List<string> headerTitles = new List<String> 
        {
            "Rész-le-tek", "Indulás", "Érkezés", "Át-szál-lás", "Idő-tartam",
			"Összeskm", "HelyjegyPótjegy", "Leg-magasabbkocsi-osztály", "Onlinejegyvásárlás"
        };

        [Test]
        public void PageObjectSearchExample()
        {
            Driver.Navigate().GoToUrl("http://elvira.mav-start.hu/");
            
            // create a new search widget object
            SearchWidget searchWidget = new SearchWidget(Driver);

            // search for route from Budapest to Szeged via Kecskemet
            searchWidget.searchForRoute("Budapest", "Szeged", "Kecskemet");
            // set reduction via text "Tanuló bérlet"
            searchWidget.setReductionViaText("Tanuló bérlet");
            // set search option to PotjegyNelkul using the searchOptions enum
            searchWidget.setSearchOptionTo(SearchWidget.searchOptions.PotjegyNelkul);

            // click on Timetable (Menetrend) button using searchWidget
            ResultWidget resultPage = searchWidget.clickTimetableButton();

            //get the number of results from resultpage
            int noOfResults = resultPage.getNoOfResults();

            Assert.Greater(noOfResults, 0);

            foreach (string headerTitle in headerTitles)
            {
                // get the result header column titles and check them that they contain the headerTitle string
                List<String> list = resultPage.getResultColumnHeaderTitles();
                Assert.True(list.Contains(headerTitle));
            }
        }
    }
}
