﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestProject
{
    class ResultWidget : BaseWidget
    {
        public ResultWidget(IWebDriver driver) : base(driver)
        {
        }

        [FindsBy(How = How.Id, Using = "timetable")]
        public IWebElement timetable { get; set; }

        public IReadOnlyCollection<IWebElement> getResultColumnHeaders()
        {
            return timetable.FindElements(By.CssSelector("#timetable > table > thead > tr:nth-child(1) > th"));
        }

        public List<String> getResultColumnHeaderTitles() 
        {
		    List<String> displayedTitles =  new List<String>();

            foreach (IWebElement element in getResultColumnHeaders())
            { displayedTitles.Add(element.Text.Trim().Replace(Environment.NewLine, string.Empty)); }
            
    	    return displayedTitles;
	    }

        public int getNoOfResults()
        {
            return (timetable.FindElements(By.CssSelector("#timetable>table>tbody>tr")).Count() / 2);
        }
    }
}
