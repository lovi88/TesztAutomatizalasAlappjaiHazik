﻿using OpenQA.Selenium;
using System;
using TechTalk.SpecFlow;

namespace TestProject
{
    [Binding]
    public class SearchSteps:TestBase
    {
        [Given(@"I'm on the home page")]
        public void GivenIMOnTheHomePage()
        {
            Driver.Navigate().GoToUrl("http://elvira.mav-start.hu");
        }
        
        [Given(@"Type ""(.*)"" to ""(.*)"" field")]
        public void GivenTypeToField(string p0, string p1)
        {
            if (p1 == "From")
                Driver.FindElement(By.Id("i")).SendKeys(p0);
            else
                Driver.FindElement(By.Id("e")).SendKeys(p1);
        }
        
        [When(@"I click ""(.*)"" button")]
        public void WhenIClickButton(string p0)
        {
            ScenarioContext.Current.Pending();
        }
        
        [Then(@"Search result appear")]
        public void ThenSearchResultAppear()
        {
            ScenarioContext.Current.Pending();
        }
    }
}
