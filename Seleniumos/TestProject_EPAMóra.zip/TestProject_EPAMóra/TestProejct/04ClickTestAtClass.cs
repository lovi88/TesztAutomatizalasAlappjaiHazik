﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;

namespace TestProject
{
    class ClickTestAtClass : TestBase
    {
        [Test]
        public void ClickSubmitExample()
        {
            Driver.Navigate().GoToUrl("http://www.elvira.hu");
            Assert.IsEmpty(Driver.FindElements(By.ClassName("calendar_date_select")));
            // Click on the yellow elvira calendar button
            
            Assert.IsTrue(Driver.FindElement(By.ClassName("calendar_date_select")).Displayed);

            String oldTitle = Driver.Title;
            // Submit search form

            Assert.AreNotEqual(oldTitle, Driver.Title);
            Assert.IsTrue(Driver.FindElement(By.ClassName("xform")).Displayed);

            oldTitle = Driver.Title;
            // Click on Máv-start logo

            Assert.AreNotEqual(oldTitle, Driver.Title);
            Assert.IsTrue(Driver.FindElement(By.Name("uff")).Displayed);
        }

        [Test]
        public void ShiftClickExample()
        {
            Driver.Navigate().GoToUrl("http://barcampomaha.org/");
            //Use Actions class to create a shift click on register link
        }
    }
}
